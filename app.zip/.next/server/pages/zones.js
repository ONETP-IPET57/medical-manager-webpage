"use strict";
(() => {
var exports = {};
exports.id = 669;
exports.ids = [669,819];
exports.modules = {

/***/ 5505:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "zoneStates": () => (/* binding */ zoneStates)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7496);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8670);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_5__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__]);
([axios__WEBPACK_IMPORTED_MODULE_5__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react/no-children-prop */ 










const zoneStates = [
    "Desocupada",
    "Ocupada"
];
const Zones = ({ data  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_6__.useSession)();
    const [searchFilter, setSearchFilter] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    const [searchType, setSearchType] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("nombre");
    const [pagination, setPagination] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const [zones, setZones] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([
        data
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        reloadPagination();
    }, [
        data,
        searchFilter,
        searchType,
        pagination
    ]);
    console.log(data);
    const handlerAddZone = ()=>{
        console.log("Add Zone");
        router.push("/zones/add");
    };
    const handlerEditZone = (id)=>{
        console.log("Edit Zone", id);
        router.push(`/zones/edit?id=${id}`);
    };
    const handlerDeleteZone = async (id)=>{
        console.log("Delete Zone", id);
        const res = await axios__WEBPACK_IMPORTED_MODULE_5__["default"]["delete"](`/api/backend/zonas/${id}`, {
            headers: {
                "Content-Type": "application/json",
                accept: "*/*",
                Authorization: `Bearer ${session?.accessToken}`
            }
        });
        if (res.status === 200) {
            router.reload();
        }
    };
    const reloadPagination = ()=>{
        const tempData = data.filter((zone)=>searchFilterFunc(zone));
        let tempPaginationPatients = [];
        for(let i = 0; i < tempData.length; i += 6){
            tempPaginationPatients.push(tempData.slice(i, i + 6));
        }
        setZones(tempPaginationPatients);
    };
    const handlerSearchZone = (e)=>{
        console.log(e.target.value);
        setSearchFilter(e.target.value);
    };
    const handlerSearchType = (e)=>{
        console.log(e.target.value);
        setSearchType(e.target.value);
    };
    const searchFilterFunc = (zone)=>{
        if (searchType === "estado") {
            return zone[searchType].toString().toLowerCase().startsWith(searchFilter.toLowerCase());
        } else if (searchType === "nombre_paciente") {
            return zone.nombre_paciente.toLowerCase().startsWith(searchFilter.toLowerCase()) || zone.apellido_paciente.toLowerCase().startsWith(searchFilter.toLowerCase());
        } else if (searchType === "nombre_enfermero") {
            return zone.nombre_enfermero.toLowerCase().startsWith(searchFilter.toLowerCase()) || zone.apellido_enfermero.toLowerCase().startsWith(searchFilter.toLowerCase());
        } else {
            return zone[searchType].toString().toLowerCase().includes(searchFilter.toLowerCase());
        }
    };
    const handlerPagination = (e)=>{
        const { value  } = e.currentTarget;
        if (value === "next") {
            setPagination(pagination + 1);
        } else if (value === "prev") {
            setPagination(pagination - 1);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_2__/* .MainContainer */ .t, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.HStack, {
                p: "0.75rem",
                spacing: "1rem",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                        as: "h2",
                        size: "lg",
                        textShadow: "md",
                        children: [
                            "Zones: ",
                            data?.length
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                        w: "min",
                        size: "sm",
                        fontSize: "20px",
                        colorScheme: "blue",
                        variant: "outline",
                        bg: "white",
                        rounded: "lg",
                        "aria-label": "Add Zone",
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_3__.IoMdAdd, {}),
                        onClick: ()=>handlerAddZone(),
                        children: "Add Zone"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        flex: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputLeftElement, {
                                pointerEvents: "none",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__.BiSearch, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                type: "text",
                                placeholder: "Search",
                                onChange: (e)=>handlerSearchZone(e)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                        defaultValue: "nombre",
                        onChange: (e)=>handlerSearchType(e),
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        flex: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "nombre",
                                children: "Nombre"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "descripcion",
                                children: "Descripcion"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "numero",
                                children: "Numero de zona"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "estado",
                                children: "Estado"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "nombre_paciente",
                                children: "Paciente"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "nombre_enfermero",
                                children: "Enfermero"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                h: "auto",
                w: "full",
                templateColumns: "repeat(6, 1fr)",
                templateRows: "auto",
                gap: "2rem",
                children: zones[pagination] ? zones[pagination].map((zone)=>{
                    return {
                        ...zone,
                        estado: zoneStates[zone.estado]
                    };
                }).map((zone)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                        rowSpan: 2,
                        colSpan: 3,
                        bg: "white",
                        p: "0.75rem",
                        rounded: "lg",
                        overflow: "hidden",
                        shadow: "md",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                            direction: "column",
                            gap: "0.5rem",
                            h: "full",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                    as: "h3",
                                    size: "md",
                                    children: zone.nombre
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                    size: "sm",
                                    color: "blackAlpha.600",
                                    children: zone.descripcion
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                    size: "sm",
                                    children: [
                                        "Estado: ",
                                        zone.estado
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                    size: "sm",
                                    children: [
                                        "Paciente: ",
                                        zone.nombre_paciente,
                                        " ",
                                        zone.apellido_paciente
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                    size: "sm",
                                    children: [
                                        "Enfermero: ",
                                        zone.nombre_enfermero,
                                        " ",
                                        zone.apellido_enfermero
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "row",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                            children: [
                                                "Lastcall: ",
                                                zone.id_llamada
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                            children: [
                                                "Zona Numero: ",
                                                zone.numero
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {
                                    mt: "auto",
                                    isAttached: true,
                                    size: "sm",
                                    variant: "outline",
                                    w: "full",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                            w: "full",
                                            colorScheme: "blue",
                                            onClick: ()=>handlerEditZone(zone.id_zona),
                                            children: "Edit"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                            w: "full",
                                            colorScheme: "blue",
                                            onClick: ()=>handlerDeleteZone(zone.id_zona),
                                            children: "Delete"
                                        })
                                    ]
                                })
                            ]
                        })
                    }, zone.id_zona)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                    colSpan: 6,
                    rowSpan: 1,
                    bg: "white",
                    rounded: "lg",
                    shadow: "md",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                        direction: "column",
                        justify: "center",
                        align: "center",
                        py: "4rem",
                        px: "2rem",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            fontSize: "lg",
                            fontWeight: "bold",
                            textTransform: "uppercase",
                            children: "No se encontraron zonas"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {
                shadow: "md",
                size: "sm",
                isAttached: true,
                variant: "outline",
                w: "full",
                colorScheme: "blue",
                bg: "white",
                rounded: "lg",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "full",
                        onClick: (e)=>handlerPagination(e),
                        value: "prev",
                        disabled: pagination === 0 || !zones[pagination],
                        children: "Prev"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "full",
                        onClick: (e)=>handlerPagination(e),
                        value: "next",
                        disabled: pagination === zones.length - 1 || !zones[pagination],
                        children: "Next"
                    })
                ]
            })
        ]
    });
};
// This gets called on every request
const getServerSideProps = async (context)=>{
    try {
        const { req , res  } = context;
        const session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_9__.unstable_getServerSession)(req, res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__/* .authOptions */ .L);
        if (!session) {
            return {
                redirect: {
                    destination: "/login",
                    permanent: false
                }
            };
        }
        // Fetch data from external API
        const resNurses = await axios__WEBPACK_IMPORTED_MODULE_5__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/zonas`, {
            headers: {
                Authorization: `Bearer ${session.accessToken}`
            }
        });
        const data = await resNurses.data;
        // Pass data to the page via props
        return {
            props: {
                data
            }
        };
    } catch (e) {
        return {
            props: {
                data: []
            }
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Zones);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [496,670], () => (__webpack_exec__(5505)));
module.exports = __webpack_exports__;

})();