"use strict";
(() => {
var exports = {};
exports.id = 735;
exports.ids = [735,819,669];
exports.modules = {

/***/ 9125:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7496);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _lib_date__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9960);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8670);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_5__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__]);
([axios__WEBPACK_IMPORTED_MODULE_5__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react/no-children-prop */ 











const Patients = ({ data  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_6__.useSession)();
    const [searchFilter, setSearchFilter] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const [searchType, setSearchType] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("nombre");
    const [pagination, setPagination] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(0);
    const [patients, setPatients] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([
        data
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        reloadPagination();
    }, [
        data,
        searchFilter,
        searchType,
        pagination
    ]);
    const handlerAddPatient = ()=>{
        console.log("Add Patient");
        router.push("/patients/add");
    };
    const handlerEditPatient = (id)=>{
        console.log("Edit Patient", id);
        router.push(`/patients/edit?id=${id}`);
    };
    const handlerDeletePatient = async (id)=>{
        console.log("Delete Patient", id);
        const res = await axios__WEBPACK_IMPORTED_MODULE_5__["default"]["delete"](`/api/backend/pacientes/${id}`, {
            headers: {
                "Content-Type": "application/json",
                accept: "*/*",
                Authorization: `Bearer ${session?.accessToken}`
            }
        });
        if (res.status === 200) {
            router.reload();
        }
    };
    const reloadPagination = ()=>{
        const tempData = data.filter((patient)=>searchFilterFunc(patient));
        let tempPaginationPatients = [];
        for(let i = 0; i < tempData.length; i += 10){
            tempPaginationPatients.push(tempData.slice(i, i + 10));
        }
        setPatients(tempPaginationPatients);
    };
    const handlerSearchPatient = (e)=>{
        console.log(e.target.value);
        setSearchFilter(e.target.value);
    };
    const handlerSearchType = (e)=>{
        console.log(e.target.value);
        setSearchType(e.target.value);
    };
    const searchFilterFunc = (patient)=>{
        if (searchType === "dni_paciente" || searchType === "telefono") {
            return patient[searchType].toString().toLowerCase().startsWith(searchFilter.toLowerCase());
        } else if (searchType === "nombre") {
            return patient.nombre.toLowerCase().startsWith(searchFilter.toLowerCase()) || patient.apellido.toLowerCase().startsWith(searchFilter.toLowerCase());
        } else if (searchType === "tipo_sangre") {
            return patient.tipo_sangre.toLowerCase() === searchFilter.toLowerCase();
        } else {
            return patient[searchType].toString().toLowerCase().includes(searchFilter.toLowerCase());
        }
    };
    const handlerPagination = (e)=>{
        const { value  } = e.currentTarget;
        if (value === "next") {
            setPagination(pagination + 1);
        } else if (value === "prev") {
            setPagination(pagination - 1);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_2__/* .MainContainer */ .t, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.HStack, {
                p: "0.75rem",
                gap: "1rem",
                flexWrap: "wrap",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                        as: "h2",
                        size: "lg",
                        children: [
                            "Patients ",
                            data?.length
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.IconButton, {
                        w: "min",
                        fontSize: "20px",
                        colorScheme: "blue",
                        variant: "ghost",
                        bg: "white",
                        rounded: "lg",
                        "aria-label": "Add Zone",
                        shadow: "md",
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_3__.IoMdAdd, {}),
                        onClick: ()=>handlerAddPatient()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "min",
                        colorScheme: "blue",
                        variant: "ghost",
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        children: "Export"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        flex: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputLeftElement, {
                                pointerEvents: "none",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_8__.BiSearch, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                type: "text",
                                placeholder: "Search",
                                onChange: (e)=>handlerSearchPatient(e)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                        defaultValue: "nombre",
                        onChange: (e)=>handlerSearchType(e),
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        flex: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "nombre",
                                children: "Nombre"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "dni_paciente",
                                children: "DNI"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "fecha_nac",
                                children: "Fecha de nacimiento"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "sexo",
                                children: "Genero"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "telefono",
                                children: "Telefono"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "tipo_sangre",
                                children: "Tipo de sangre"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Accordion, {
                allowToggle: true,
                w: "full",
                children: patients[pagination] ? patients[pagination].map((patient)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionItem, {
                        my: "1rem",
                        bg: "white",
                        rounded: "lg",
                        border: "none",
                        shadow: "md",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionButton, {
                                p: "1rem",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                        direction: "row",
                                        w: "full",
                                        gap: "0.5rem",
                                        justify: "flex-start",
                                        align: "center",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                                as: "h3",
                                                size: "md",
                                                children: [
                                                    patient.nombre,
                                                    " ",
                                                    patient.apellido
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                fontSize: "sm",
                                                children: patient.dni_paciente
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionIcon, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.AccordionPanel, {
                                pb: 4,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    gap: 4,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                            direction: "row",
                                            w: "full",
                                            h: "full",
                                            gap: "0.5rem",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Telefono"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            children: patient.telefono
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Genero"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            children: patient.sexo
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                            direction: "row",
                                            w: "full",
                                            gap: "0.5rem",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Fecha de nacimiento"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            children: (0,_lib_date__WEBPACK_IMPORTED_MODULE_11__/* .formatDateToHuman */ .lP)(patient.fecha_nac)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Direccion"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            children: patient.direccion
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                            direction: "row",
                                            w: "full",
                                            gap: "0.5rem",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Patologias"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            children: patient.patologia ? patient.patologia : "Sin patologias registradas"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Alergia"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            children: patient.alergia ? patient.alergia : "Sin alergias registradas"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                        patient.ultimo_antecedente ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                    direction: "column",
                                                    w: "full",
                                                    gap: "0.5rem",
                                                    flex: "1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                            fontSize: "md",
                                                            fontWeight: "bold",
                                                            children: "Ultimo antecedente"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                            direction: "row",
                                                            w: "full",
                                                            gap: "0.5rem",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                                    direction: "column",
                                                                    w: "full",
                                                                    gap: "0.5rem",
                                                                    flex: "1",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                                            fontSize: "md",
                                                                            fontWeight: "bold",
                                                                            children: "Fecha"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                                            fontSize: "md",
                                                                            children: patient.ultimo_antecedente.fecha
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                                    direction: "column",
                                                                    w: "full",
                                                                    gap: "0.5rem",
                                                                    flex: "1",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                                            fontSize: "md",
                                                                            fontWeight: "bold",
                                                                            children: "Motivo"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                                            fontSize: "md",
                                                                            children: patient.ultimo_antecedente.motivo
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                                                    direction: "column",
                                                                    w: "full",
                                                                    gap: "0.5rem",
                                                                    flex: "1",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                                            fontSize: "md",
                                                                            fontWeight: "bold",
                                                                            children: "Diagnostico"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                                            fontSize: "md",
                                                                            children: patient.ultimo_antecedente.diagnostico
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {})
                                            ]
                                        }) : null,
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                            direction: "row",
                                            w: "full",
                                            gap: "0.5rem",
                                            justify: "space-between",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                                    colorScheme: "blue",
                                                    mr: "0.5rem",
                                                    children: [
                                                        "Fecha de ingreso: ",
                                                        (0,_lib_date__WEBPACK_IMPORTED_MODULE_11__/* .formatDatetimeToHuman */ .M$)(patient.fecha_hora_ingreso)
                                                    ]
                                                }),
                                                patient.fecha_hora_egreso ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                                    colorScheme: "green",
                                                    mr: "0.5rem",
                                                    children: [
                                                        "Fecha de egreso: ",
                                                        (0,_lib_date__WEBPACK_IMPORTED_MODULE_11__/* .formatDatetimeToHuman */ .M$)(patient.fecha_hora_egreso)
                                                    ]
                                                }) : null
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {
                                            isAttached: true,
                                            variant: "outline",
                                            colorScheme: "blue",
                                            size: "md",
                                            w: "full",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                    w: "full",
                                                    onClick: ()=>handlerEditPatient(patient.dni_paciente),
                                                    children: "Edit"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                    w: "full",
                                                    onClick: ()=>handlerDeletePatient(patient.dni_paciente),
                                                    children: "Delete"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }, patient.dni_paciente)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                    direction: "column",
                    w: "full",
                    justify: "center",
                    align: "center",
                    py: "4rem",
                    px: "2rem",
                    bg: "white",
                    rounded: "lg",
                    shadow: "md",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        fontSize: "lg",
                        fontWeight: "bold",
                        textTransform: "uppercase",
                        children: "No se encontraron pacientes"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {
                shadow: "md",
                size: "sm",
                isAttached: true,
                variant: "outline",
                w: "full",
                colorScheme: "blue",
                bg: "white",
                rounded: "lg",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "full",
                        onClick: (e)=>handlerPagination(e),
                        value: "prev",
                        disabled: pagination === 0 || !patients[pagination],
                        children: "Prev"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "full",
                        onClick: (e)=>handlerPagination(e),
                        value: "next",
                        disabled: pagination === patients.length - 1 || !patients[pagination],
                        children: "Next"
                    })
                ]
            })
        ]
    });
};
// This gets called on every request
const getServerSideProps = async (context)=>{
    try {
        const { req , res  } = context;
        const session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_9__.unstable_getServerSession)(req, res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_10__/* .authOptions */ .L);
        if (!session) {
            return {
                redirect: {
                    destination: "/login",
                    permanent: false
                }
            };
        }
        // Fetch data from external API
        const resNurses = await axios__WEBPACK_IMPORTED_MODULE_5__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/pacientes`, {
            headers: {
                Authorization: `Bearer ${session.accessToken}`
            }
        });
        const data = await resNurses.data;
        // Pass data to the page via props
        return {
            props: {
                data
            }
        };
    } catch (e) {
        return {
            props: {
                data: []
            }
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Patients);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [496,670,960], () => (__webpack_exec__(9125)));
module.exports = __webpack_exports__;

})();