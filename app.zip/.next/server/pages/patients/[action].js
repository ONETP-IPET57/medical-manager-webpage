"use strict";
(() => {
var exports = {};
exports.id = 241;
exports.ids = [241];
exports.modules = {

/***/ 4273:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7496);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2113);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8670);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _lib_date__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9960);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_7__, axios__WEBPACK_IMPORTED_MODULE_8__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_7__, axios__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react/no-children-prop */ 










const PatientActions = ({ data  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { action , id  } = router.query;
    const isEdit = action === "edit";
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.useSession)();
    const { register , handleSubmit , watch , formState: { errors , isSubmitting  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)();
    const onSubmit = (values)=>{
        console.log(values);
        if (isEdit) {
            return axios__WEBPACK_IMPORTED_MODULE_8__["default"].post(`/api/backend/pacientes/${id}`, {
                ...data,
                ...values,
                fecha_nac: new Date(values.fecha_nac).toISOString().split("T")[0],
                fecha_hora_ingreso: (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDatetimeToSQL */ .vU)(values.fecha_hora_ingreso),
                fecha_hora_egreso: (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDatetimeToSQL */ .vU)(values.fecha_hora_egreso)
            }, {
                headers: {
                    "Content-Type": "application/json",
                    accept: "*/*",
                    Authorization: `Bearer ${session?.accessToken}`
                }
            }).then((res)=>{
                console.log(res);
                router.push("/patients");
            }).catch((err)=>{
                console.log(err);
                if (err.response.status === 401) {
                    router.push("/login");
                }
            });
        } else {
            return axios__WEBPACK_IMPORTED_MODULE_8__["default"].post("/api/backend/pacientes", {
                ...values,
                fecha_nac: new Date(values.fecha_nac).toISOString().split("T")[0],
                fecha_hora_ingreso: (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDatetimeToSQL */ .vU)(values.fecha_hora_ingreso),
                fecha_hora_egreso: (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDatetimeToSQL */ .vU)(values.fecha_hora_egreso)
            }, {
                headers: {
                    "Content-Type": "application/json",
                    accept: "*/*",
                    Authorization: `Bearer ${session?.accessToken}`
                }
            }).then((res)=>{
                console.log(res);
                router.push("/patients");
            }).catch((err)=>{
                console.log(err);
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_3__/* .MainContainer */ .t, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.HStack, {
                p: "0.75rem",
                spacing: "1rem",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                    as: "h2",
                    size: "lg",
                    children: "Patients"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: handleSubmit(onSubmit),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                    direction: "column",
                    p: "1rem",
                    gap: "1rem",
                    bg: "white",
                    rounded: "xl",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.nombre),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.nombre : "",
                                    placeholder: "Add the name of patient",
                                    ...register("nombre", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.nombre ? errors.nombre.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.apellido),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Lastname"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.apellido : "",
                                    placeholder: "Add the lastname of patient",
                                    ...register("apellido", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.apellido ? errors.apellido.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.dni_paciente),
                            isDisabled: action === "edit",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "DNI"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "tel",
                                    placeholder: "Dni",
                                    defaultValue: isEdit ? data?.dni_paciente : "",
                                    ...action === "add" ? register("dni_paciente", {
                                        required: "This is required",
                                        minLength: {
                                            value: 8,
                                            message: "Minimum length should be 8"
                                        },
                                        maxLength: {
                                            value: 11,
                                            message: "Maximum length should be 11"
                                        },
                                        pattern: {
                                            value: /^[0-9]+$/i,
                                            message: "Numbers only"
                                        }
                                    }) : {}
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.dni_paciente ? errors.dni_paciente.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.fecha_nac),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Birth date"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    placeholder: "Select the birth date of patient",
                                    size: "md",
                                    type: "date",
                                    defaultValue: isEdit ? (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDateToHTMLInput */ .Pq)(data?.fecha_nac) : "",
                                    ...register("fecha_nac", {
                                        required: "This is required"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.fecha_nac ? errors.fecha_nac.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.sexo),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Gender"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                    placeholder: "Select Gender of patient",
                                    defaultValue: isEdit ? data?.sexo : "",
                                    ...register("sexo", {
                                        required: "This is required"
                                    }),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "Masculino",
                                            children: "Male"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "Femenino",
                                            children: "Female"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.sexo ? errors.sexo.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.telefono),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Phone"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputLeftElement, {
                                            pointerEvents: "none",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__.BiPhone, {})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                            type: "tel",
                                            placeholder: "Phone number",
                                            defaultValue: isEdit ? data?.telefono : "",
                                            ...register("telefono", {
                                                required: "This is required",
                                                minLength: {
                                                    value: 7,
                                                    message: "Minimum length should be 7"
                                                },
                                                maxLength: {
                                                    value: 10,
                                                    message: "Minimum length should be 10"
                                                },
                                                pattern: {
                                                    value: /^[0-9]+$/i,
                                                    message: "Numbers only"
                                                }
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.telefono ? errors.telefono.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.direccion),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Address"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.direccion : "",
                                    placeholder: "Add the address of patient",
                                    ...register("direccion", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.direccion ? errors.direccion.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.fecha_hora_ingreso),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Entry day"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    placeholder: "Select the Entry day of patient",
                                    size: "md",
                                    type: "datetime-local",
                                    defaultValue: isEdit ? (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDatetimeToHTMLInput */ .AY)(data?.fecha_hora_ingreso) : "",
                                    ...register("fecha_hora_ingreso", {
                                        required: "This is required"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.fecha_hora_ingreso ? errors.fecha_hora_ingreso.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.fecha_hora_egreso),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Exit day"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    placeholder: "Select the Exit day of patient",
                                    size: "md",
                                    type: "datetime-local",
                                    defaultValue: isEdit ? (0,_lib_date__WEBPACK_IMPORTED_MODULE_10__/* .formatDatetimeToHTMLInput */ .AY)(data?.fecha_hora_egreso) : "",
                                    ...register("fecha_hora_egreso")
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.fecha_hora_egreso ? errors.fecha_hora_egreso.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.tipo_sangre),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Tipo sangre"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                    placeholder: "Select blood type of patient",
                                    defaultValue: isEdit ? data?.tipo_sangre : "",
                                    ...register("tipo_sangre", {
                                        required: "This is required"
                                    }),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "A",
                                            children: "A"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "B",
                                            children: "B"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "AB",
                                            children: "AB"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "O",
                                            children: "O"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.tipo_sangre ? errors.tipo_sangre.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.patologia),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Patologias"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.patologia : "",
                                    placeholder: "Add the address of patient",
                                    ...register("patologia", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.patologia ? errors.patologia.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.alergia),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Alergias"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.alergia : "",
                                    placeholder: "Add the address of patient",
                                    ...register("alergia", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.alergia ? errors.alergia.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                            colorScheme: "blue",
                            variant: "solid",
                            rounded: "md",
                            w: "full",
                            type: "submit",
                            children: "Submit"
                        })
                    ]
                })
            })
        ]
    });
};
// This gets called on every request
const getServerSideProps = async (context)=>{
    try {
        const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_6__.unstable_getServerSession)(context.req, context.res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_7__/* .authOptions */ .L);
        if (!session) {
            return {
                redirect: {
                    destination: "/",
                    permanent: false
                }
            };
        }
        let data = null;
        if (context.query.action === "edit") {
            // Fetch data from external API
            const res = await axios__WEBPACK_IMPORTED_MODULE_8__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/pacientes/${context.query.id}`, {
                headers: {
                    Authorization: `Bearer ${session.accessToken}`
                }
            });
            data = await res.data;
        }
        // Pass data to the page via props
        return {
            props: {
                data
            }
        };
    } catch (e) {
        return {
            props: {
                data: null
            }
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PatientActions);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [496,670,960], () => (__webpack_exec__(4273)));
module.exports = __webpack_exports__;

})();