"use strict";
(() => {
var exports = {};
exports.id = 708;
exports.ids = [708];
exports.modules = {

/***/ 5440:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7496);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2113);
/* harmony import */ var next_auth_next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8670);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_6__, axios__WEBPACK_IMPORTED_MODULE_7__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_6__, axios__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ZonesActions = ({ data , dataNurses , dataPatients  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { action , id  } = router.query;
    const isEdit = action === "edit";
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_8__.useSession)();
    console.log(data);
    const { register , handleSubmit , watch , formState: { errors , isSubmitting  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)();
    const onSubmit = (values)=>{
        console.log(values);
        if (isEdit) {
            return axios__WEBPACK_IMPORTED_MODULE_7__["default"].post(`/api/backend/zonas/${id}`, {
                ...data,
                ...values
            }, {
                headers: {
                    "Content-Type": "application/json",
                    accept: "*/*",
                    Authorization: `Bearer ${session?.accessToken}`
                }
            }).then((res)=>{
                console.log(res);
                router.push("/zones");
            }).catch((err)=>{
                console.log(err);
                if (err.response.status === 401) {
                    router.push("/login");
                }
            });
        } else {
            return axios__WEBPACK_IMPORTED_MODULE_7__["default"].post("/api/backend/zonas", {
                ...values,
                id_llamada: 1
            }, {
                headers: {
                    "Content-Type": "application/json",
                    accept: "*/*",
                    Authorization: `Bearer ${session?.accessToken}`
                }
            }).then((res)=>{
                console.log(res);
                router.push("/zones");
            }).catch((err)=>{
                console.log(err);
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_3__/* .MainContainer */ .t, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.HStack, {
                p: "0.75rem",
                spacing: "1rem",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                    as: "h2",
                    size: "lg",
                    children: "Zones"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: handleSubmit(onSubmit),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                    direction: "column",
                    p: "1rem",
                    gap: "1rem",
                    bg: "white",
                    rounded: "xl",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.nombre),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Zone Name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.nombre : "",
                                    placeholder: "Add a name",
                                    ...register("nombre", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.nombre ? errors.nombre.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.descripcion),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Description"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.descripcion : "",
                                    placeholder: "Add a descripcion",
                                    ...register("descripcion", {
                                        required: "This is required",
                                        minLength: {
                                            value: 4,
                                            message: "Minimum length should be 4"
                                        },
                                        pattern: {
                                            value: /^[a-zA-Z0-9\_\-\s]+$/i,
                                            message: "Alphanumeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.descripcion ? errors.descripcion.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.numero),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Zone Number"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                    type: "text",
                                    defaultValue: isEdit ? data?.numero : "",
                                    placeholder: "Add a numero",
                                    ...register("numero", {
                                        required: "This is required",
                                        pattern: {
                                            value: /^[0-9]+$/i,
                                            message: "Numeric characters only"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.numero ? errors.numero.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.estado),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Estado"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                    placeholder: "Select estado",
                                    defaultValue: isEdit ? data?.estado : "",
                                    ...register("estado", {
                                        required: "This is required"
                                    }),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "0",
                                            children: "Desocupado"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "1",
                                            children: "Ocupado"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.estado ? errors.estado.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.id_forma_llamada),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Forma de llamada"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                    placeholder: "Select Patient",
                                    defaultValue: isEdit ? data?.id_forma_llamada : "",
                                    ...register("id_forma_llamada", {
                                        required: "This is required"
                                    }),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "1",
                                            children: "Llamada de paciente"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                            value: "2",
                                            children: "Televisor"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.id_forma_llamada ? errors.id_forma_llamada.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.dni_paciente),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Patient"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                    placeholder: "Select Patient",
                                    defaultValue: isEdit ? data?.dni_paciente : "",
                                    ...register("dni_paciente", {
                                        required: "This is required"
                                    }),
                                    children: dataPatients?.map((patient)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                            value: patient.dni_paciente,
                                            children: [
                                                patient.nombre,
                                                " ",
                                                patient.apellido
                                            ]
                                        }, patient.dni_paciente))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.dni_paciente ? errors.dni_paciente.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                            isInvalid: Boolean(errors.dni_enfermero),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                    children: "Nurse"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                    placeholder: "Select Nurse",
                                    defaultValue: isEdit ? data?.dni_enfermero : "",
                                    ...register("dni_enfermero", {
                                        required: "This is required"
                                    }),
                                    children: dataNurses?.map((nurse)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                            value: nurse.dni_enfermero,
                                            children: [
                                                nurse.nombre,
                                                " ",
                                                nurse.apellido
                                            ]
                                        }, nurse.dni_enfermero))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.FormErrorMessage, {
                                    children: errors.dni_enfermero ? errors.dni_enfermero.message : ""
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                            colorScheme: "blue",
                            variant: "solid",
                            rounded: "md",
                            w: "full",
                            type: "submit",
                            isLoading: isSubmitting,
                            children: "Submit"
                        })
                    ]
                })
            })
        ]
    });
};
// This gets called on every request
const getServerSideProps = async (context)=>{
    try {
        const session = await (0,next_auth_next__WEBPACK_IMPORTED_MODULE_5__.unstable_getServerSession)(context.req, context.res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_6__/* .authOptions */ .L);
        if (!session) {
            return {
                redirect: {
                    destination: "/login",
                    permanent: false
                }
            };
        }
        let data = null;
        if (context.query.action === "edit") {
            // Fetch data from external API
            const res = await axios__WEBPACK_IMPORTED_MODULE_7__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/zonas/${context.query.id}`, {
                headers: {
                    Authorization: `Bearer ${session.accessToken}`
                }
            });
            data = await res.data;
            console.log(res.data);
        }
        // Fetch data from external API
        const resNurses = await axios__WEBPACK_IMPORTED_MODULE_7__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/enfermeros`, {
            headers: {
                Authorization: `Bearer ${session.accessToken}`
            }
        });
        const dataNurses = await resNurses.data;
        // Fetch data from external API
        const resPatients = await axios__WEBPACK_IMPORTED_MODULE_7__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/pacientes`, {
            headers: {
                Authorization: `Bearer ${session.accessToken}`
            }
        });
        const dataPatients = await resPatients.data;
        // Pass data to the page via props
        return {
            props: {
                data,
                dataNurses,
                dataPatients,
                session
            }
        };
    } catch (e) {
        if (e?.response?.status === 401) {
            return {
                redirect: {
                    destination: "/login",
                    permanent: false
                }
            };
        }
        return {
            props: {
                data: null,
                dataNurses: null,
                dataPatients: null
            }
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ZonesActions);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 2113:
/***/ ((module) => {

module.exports = require("next-auth/next");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [496,670], () => (__webpack_exec__(5440)));
module.exports = __webpack_exports__;

})();