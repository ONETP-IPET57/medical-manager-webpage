"use strict";
(() => {
var exports = {};
exports.id = 924;
exports.ids = [924];
exports.modules = {

/***/ 5337:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7496);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9648);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8670);
/* harmony import */ var _lib_date__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9960);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_3__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_8__]);
([axios__WEBPACK_IMPORTED_MODULE_3__, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react/no-children-prop */ 









const Calls = ({ data  })=>{
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_6__.useSession)();
    const [searchFilter, setSearchFilter] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const [searchType, setSearchType] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("id_llamada");
    const [pagination, setPagination] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const [calls, setCalls] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([
        data
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        reloadPagination();
        console.log(data);
    }, [
        data,
        searchFilter,
        searchType,
        pagination
    ]);
    const handlerSearchCall = (e)=>{
        console.log(e.target.value);
        setSearchFilter(e.target.value);
    };
    const handlerSearchType = (e)=>{
        console.log(e.target.value);
        setSearchType(e.target.value);
    };
    const reloadPagination = ()=>{
        const tempData = data.filter((call)=>searchFilterFunc(call));
        let tempPaginationData = [];
        for(let i = 0; i < tempData.length; i += 4){
            tempPaginationData.push(tempData.slice(i, i + 4));
        }
        setCalls(tempPaginationData);
    };
    const searchFilterFunc = (call)=>{
        if (searchType === "tipo" || searchType === "origen_llamada" || searchType === "id_llamada") {
            return call[searchType].toString().toLowerCase().startsWith(searchFilter.toLowerCase());
        } else if (searchType === "nombre_paciente") {
            return call.nombre_paciente.toLowerCase().startsWith(searchFilter.toLowerCase()) || call.apellido_paciente.toLowerCase().startsWith(searchFilter.toLowerCase());
        } else if (searchType === "fecha_hora_atentido") {
            if (!call.fecha_hora_atendido) {
                if (searchFilter.length > 0) {
                    return "no atendido".startsWith(searchFilter);
                } else {
                    return true;
                }
            } else {
                return call.fecha_hora_atendido.toString().toLowerCase().includes(searchFilter.toLowerCase());
            }
        } else {
            return call[searchType].toString().toLowerCase().includes(searchFilter.toLowerCase());
        }
    };
    const handlerPagination = (e)=>{
        const { value  } = e.currentTarget;
        if (value === "next") {
            setPagination(pagination + 1);
        } else if (value === "prev") {
            setPagination(pagination - 1);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_MainContainer__WEBPACK_IMPORTED_MODULE_2__/* .MainContainer */ .t, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.HStack, {
                p: "0.75rem",
                gap: "1rem",
                flexWrap: "wrap",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                        as: "h2",
                        size: "lg",
                        children: [
                            "Calls: ",
                            data?.length
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "min",
                        colorScheme: "blue",
                        variant: "ghost",
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        children: "Export"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputGroup, {
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        flex: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.InputLeftElement, {
                                pointerEvents: "none",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__.BiSearch, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                type: "text",
                                placeholder: "Search",
                                onChange: (e)=>handlerSearchCall(e)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Select, {
                        defaultValue: "nombre",
                        onChange: (e)=>handlerSearchType(e),
                        bg: "white",
                        rounded: "lg",
                        shadow: "md",
                        flex: "1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "id_llamada",
                                children: "Numero de llamada"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "tipo",
                                children: "Tipo de llamada"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "fecha_hora_llamada",
                                children: "Fecha y hora de llamada"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "fecha_hora_atendido",
                                children: "Fecha y hora de atendido"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "origen_llamada",
                                children: "Origen de la Llamada"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "nombre_zona",
                                children: "Nombre de la zona"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "nombre_paciente",
                                children: "Paciente"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                h: "auto",
                w: "full",
                templateColumns: {
                    base: "auto",
                    md: "repeat(6, 1fr)"
                },
                templateRows: "auto",
                gap: "2rem",
                children: calls[pagination] ? calls[pagination]/* .map((call) => {
            return {
              ...call,
              estado: zoneStates[zone.estado],
            };
          }) */ .map((call)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                        rowSpan: 2,
                        colSpan: 3,
                        bg: "white",
                        p: "0.75rem",
                        rounded: "lg",
                        shadow: "md",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                            direction: "column",
                            gap: "0.5rem",
                            h: "full",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                    as: "h3",
                                    size: "md",
                                    children: [
                                        "Llamada numero: ",
                                        call.id_llamada
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    w: "full",
                                    gap: "0.5rem",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            fontWeight: "bold",
                                            children: "Zona"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            children: [
                                                call.nombre_zona,
                                                " - ",
                                                call.numero_zona
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    w: "full",
                                    gap: "0.5rem",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            fontWeight: "bold",
                                            children: "Paciente"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            children: [
                                                call.nombre_paciente,
                                                " ",
                                                call.apellido_paciente
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    w: "full",
                                    gap: "0.5rem",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            fontWeight: "bold",
                                            children: "Origen llamada"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            children: call.origen_llamada
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    w: "full",
                                    gap: "0.5rem",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            fontWeight: "bold",
                                            children: "Tipo de llamada"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: "md",
                                            children: call.tipo
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                                    direction: "column",
                                    w: "full",
                                    gap: "0.5rem",
                                    justify: "space-between",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                            colorScheme: "blue",
                                            mr: "0.5rem",
                                            children: [
                                                "Fecha y hora de llamada: ",
                                                (0,_lib_date__WEBPACK_IMPORTED_MODULE_9__/* .formatDatetimeToHuman */ .M$)(call.fecha_hora_llamada)
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Badge, {
                                            colorScheme: "green",
                                            mr: "0.5rem",
                                            children: call.fecha_hora_atentido ? "Fecha y hora de atencion: " + (0,_lib_date__WEBPACK_IMPORTED_MODULE_9__/* .formatDatetimeToHuman */ .M$)(call.fecha_hora_atentido) : "No atendido"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Divider, {})
                            ]
                        })
                    }, call.id_llamada)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                    colSpan: 6,
                    rowSpan: 1,
                    bg: "white",
                    rounded: "lg",
                    shadow: "md",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Flex, {
                        direction: "column",
                        justify: "center",
                        align: "center",
                        py: "4rem",
                        px: "2rem",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            fontSize: "lg",
                            fontWeight: "bold",
                            textTransform: "uppercase",
                            children: "No se encontraron Llamadas"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ButtonGroup, {
                shadow: "md",
                size: "sm",
                isAttached: true,
                variant: "outline",
                w: "full",
                colorScheme: "blue",
                bg: "white",
                rounded: "lg",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "full",
                        onClick: (e)=>handlerPagination(e),
                        value: "prev",
                        disabled: pagination === 0 || !calls[pagination],
                        children: "Prev"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        w: "full",
                        onClick: (e)=>handlerPagination(e),
                        value: "next",
                        disabled: pagination === calls.length - 1 || !calls[pagination],
                        children: "Next"
                    })
                ]
            })
        ]
    });
};
// This gets called on every request
const getServerSideProps = async (context)=>{
    try {
        const { req , res  } = context;
        const session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_7__.unstable_getServerSession)(req, res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_8__/* .authOptions */ .L);
        if (!session) {
            return {
                redirect: {
                    destination: "/login",
                    permanent: false
                }
            };
        }
        // Fetch data from external API
        const resLlamadas = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"https://hospitalbackend.pythonanywhere.com"}/api/llamadas`, {
            headers: {
                Authorization: `Bearer ${session.accessToken}`
            }
        });
        const data = await resLlamadas.data;
        console.log(data);
        // Pass data to the page via props
        return {
            props: {
                data
            }
        };
    } catch (e) {
        return {
            props: {
                data: []
            }
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Calls);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [496,670,960], () => (__webpack_exec__(5337)));
module.exports = __webpack_exports__;

})();