"use strict";
exports.id = 496;
exports.ids = [496];
exports.modules = {

/***/ 7496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "t": () => (/* binding */ MainContainer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
// EXTERNAL MODULE: external "react-icons/tb"
var tb_ = __webpack_require__(4152);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next-auth/react"
var external_next_auth_react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./components/Menu.tsx







const menuItems = [
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiHome, {}),
        title: "Home",
        link: "/",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiClinic, {}),
        title: "Zones",
        link: "/zones",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiBody, {}),
        title: "Patients",
        link: "/patients",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(tb_.TbNurse, {}),
        title: "Nurses",
        link: "/nurses",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiPhoneCall, {}),
        title: "Calls",
        link: "/calls",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiDoughnutChart, {}),
        title: "Reports",
        link: "/reports",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiError, {}),
        title: "Alerta",
        link: "/alert/encargado",
        role: "all"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiUser, {}),
        title: "Users",
        link: "/users",
        role: "administrador"
    },
    {
        icon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiCog, {}),
        title: "Settings",
        link: "/settings",
        role: "administrador"
    }
];
const Menu = ()=>{
    const router = (0,router_.useRouter)();
    const { data: session  } = (0,external_next_auth_react_.useSession)();
    console.log(session);
    const logout = ()=>{
        console.log("logout");
        (0,external_next_auth_react_.signOut)({
            callbackUrl: "/login"
        });
    };
    const handlerButtonSection = (link)=>{
        console.log(link);
        router.push(link);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        h: "100vh",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
            direction: "column",
            gap: "1rem",
            p: "2rem",
            justifyContent: "flex-start",
            alignItems: "center",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Heading, {
                    as: "h4",
                    size: "lg",
                    children: [
                        "Welcome ",
                        session?.user.username
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Badge, {
                    colorScheme: "blue",
                    children: session?.user.role
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Divider, {}),
                menuItems.map((item)=>{
                    if (item.role === "all" || item.role === session?.user.role) return /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                        colorScheme: "blue",
                        variant: "ghost",
                        leftIcon: item.icon,
                        w: "full",
                        onClick: ()=>handlerButtonSection(item.link),
                        children: item.title
                    }, item.title);
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                    w: "full",
                    variant: "ghost",
                    colorScheme: "blue",
                    leftIcon: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                        as: bi_.BiLogOut
                    }),
                    onClick: ()=>logout(),
                    children: "Logout"
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/layouts/MainContainer.tsx




const MainContainer = ({ children  })=>{
    const { isOpen , onOpen , onClose  } = (0,react_.useDisclosure)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                display: {
                    base: "none",
                    md: "flex"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(Menu, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                display: {
                    base: "flex",
                    md: "none"
                },
                w: "full",
                h: "full",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Drawer, {
                    isOpen: isOpen,
                    placement: "left",
                    onClose: onClose,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.DrawerOverlay, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.DrawerContent, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Menu, {})
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                direction: "column",
                bg: "blackAlpha.200",
                w: {
                    base: "full",
                    md: "75%"
                },
                h: "full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                        display: {
                            base: "flex",
                            md: "none"
                        },
                        w: "full",
                        bg: "white",
                        shadow: "md",
                        position: "fixed",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            colorScheme: "blue",
                            onClick: onOpen,
                            variant: "ghost",
                            leftIcon: /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiMenu, {}),
                            children: "Menu"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                        direction: "column",
                        bg: "blackAlpha.200",
                        w: "full",
                        h: "full",
                        p: "1rem",
                        gap: "1rem",
                        mt: {
                            base: "40px",
                            md: "0"
                        },
                        children: children
                    })
                ]
            })
        ]
    });
};


/***/ })

};
;