"use strict";
exports.id = 960;
exports.ids = [960];
exports.modules = {

/***/ 9960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AY": () => (/* binding */ formatDatetimeToHTMLInput),
/* harmony export */   "Ay": () => (/* binding */ getAge),
/* harmony export */   "M$": () => (/* binding */ formatDatetimeToHuman),
/* harmony export */   "Pq": () => (/* binding */ formatDateToHTMLInput),
/* harmony export */   "bY": () => (/* binding */ formatDateToSQL),
/* harmony export */   "lP": () => (/* binding */ formatDateToHuman),
/* harmony export */   "vU": () => (/* binding */ formatDatetimeToSQL)
/* harmony export */ });
const getAge = (birth_date)=>{
    const today = new Date();
    const birthDate = new Date(birth_date);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || m === 0 && today.getDate() < birthDate.getDate()) {
        age--;
    }
    return age;
};
const formatDateToHTMLInput = (date)=>{
    if (!date) {
        return "";
    }
    const d = new Date(date);
    const month = `${d.getMonth() + 1}`.padStart(2, "0");
    const day = `${d.getDate()}`.padStart(2, "0");
    const year = d.getFullYear();
    return [
        year,
        month,
        day
    ].join("-");
};
const formatDateToHuman = (date)=>{
    if (!date) {
        return "";
    }
    const d = new Date(date);
    const month = `${d.getMonth() + 1}`.padStart(2, "0");
    const day = `${d.getDate()}`.padStart(2, "0");
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
};
const formatDatetimeToHTMLInput = (datetime)=>{
    if (!datetime) {
        return "";
    }
    const d = new Date(datetime);
    const month = `${d.getMonth() + 1}`.padStart(2, "0");
    const day = `${d.getDate()}`.padStart(2, "0");
    const year = d.getFullYear();
    const hour = `${d.getHours()}`.padStart(2, "0");
    const minute = `${d.getMinutes()}`.padStart(2, "0");
    return [
        year,
        month,
        day
    ].join("-") + "T" + [
        hour,
        minute
    ].join(":");
};
const formatDatetimeToHuman = (datetime)=>{
    if (!datetime) {
        return "";
    }
    const d = new Date(datetime);
    const month = `${d.getMonth() + 1}`.padStart(2, "0");
    const day = `${d.getDate()}`.padStart(2, "0");
    const year = d.getFullYear();
    const hour = `${d.getHours()}`.padStart(2, "0");
    const minute = `${d.getMinutes()}`.padStart(2, "0");
    return `${day}/${month}/${year} ${hour}:${minute}`;
};
const formatDateToSQL = (date)=>{
    if (!date) {
        return "";
    }
    const d = new Date(date);
    const month = `${d.getMonth() + 1}`.padStart(2, "0");
    const day = `${d.getDate()}`.padStart(2, "0");
    const year = d.getFullYear();
    return [
        year,
        month,
        day
    ].join("-");
};
const formatDatetimeToSQL = (datetime)=>{
    if (!datetime) {
        return "";
    }
    const d = new Date(datetime);
    const month = `${d.getMonth() + 1}`.padStart(2, "0");
    const day = `${d.getDate()}`.padStart(2, "0");
    const year = d.getFullYear();
    const hour = `${d.getHours()}`.padStart(2, "0");
    const minute = `${d.getMinutes()}`.padStart(2, "0");
    const second = `${d.getSeconds()}`.padStart(2, "0");
    return [
        year,
        month,
        day
    ].join("-") + " " + [
        hour,
        minute,
        second
    ].join(":");
};


/***/ })

};
;